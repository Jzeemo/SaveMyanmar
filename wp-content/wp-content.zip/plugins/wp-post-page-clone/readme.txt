=== WP Post Page Clone ===
Contributors: gaurangsondagar
Donate link: http://gaurangsondagar99.wordpress.com/
Tags: clone post, clone page, duplicate post, duplicate page, clone post and page, duplicate post and page
Requires at least: 4.0
Tested up to: 5.5.3
Stable tag: 1.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Clone Post or Page with it's contents and settings in just one click.

== Description ==
WP Post Page Clone is a WordPress plugin that allows you to easily duplicate or clone post/page in just one click.

WP Post Page Clone Plugin Features

* Clone post with it's contents and settings in just one click.
* Clone page with it's contents and settings in just one click.
* Cross Browsers Support ( Firefox, Chrome, Safari, Opera, etc. )

== Installation ==

* Upload the **wp-post-page-clone.zip** file Via WordPress Admin > Plugins > Add New,
* Alternately, upload **wp-post-page-clone** folder to the /wp-content/plugins/ directory via FTP,
* Activate the **WP Post Page Clone** plugin from Admin > Plugins.
* Now go to the all posts or all pages from your dashboard
* Just Hover your cursor on any post or page then you will see a "Click To Clone" link
* Click on this link to clone your post/page with it's all settings of your previous page.

== Frequently Asked Questions ==
 
= How to create a duplicate of post ? =

* Activate the plugin from the 'Plugins' menu in Dashboard
* Now go to all posts on your dashboard
* Hover your cursor over any post you will see a "Click To Clone" link
* Click on this link to clone your post with it's all settings of your previous post.

= How to create a duplicate of page ? =

* Activate the plugin from the 'Plugins' menu in Dashboard
* Now go to all pages on your dashboard
* Hover your cursor over any page you will see a "Click To Clone" link
* Click on this link to clone your page with it's all settings of your previous page.
 
== Screenshots ==

1. screenshot-1.png

== Changelog ==

= 1.1 (10th May, 2020) =

* Security issues fixes addressed by Securi